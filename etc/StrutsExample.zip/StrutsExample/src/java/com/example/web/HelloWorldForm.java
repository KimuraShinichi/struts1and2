package com.example.web;

import org.apache.struts.action.ActionForm;

public class HelloWorldForm extends ActionForm {
    // フォームのフィールドとアクセサメソッドをここに記述
}
